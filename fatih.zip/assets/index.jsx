// import ICGoogle from './images/google.png'
// import ICFacebook from './images/facebook.png'
import Person from './images/lock1.png'

export {
    Person
}