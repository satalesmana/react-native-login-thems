import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  CheckBox,
  Image,
  ImageBackground,
  Alert
} from 'react-native';
import { MyButton } from '../../components'
import { ICFacebook, ICGoogle, ICApple, Person} from '../../../assets'
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import React from 'react'

const LoginScreen = () => {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');

  const windowWidth = Dimensions.get('window').width;
  const [checked, setChecked] = React.useState(false);

  const handleLogin = () => {
      // Handle login logic here
      console.log('Email:', email);
      console.log('Password:', password);
      navigation.replace("home")
  };

  return (
    <ScrollView>
        <View>
          <ImageBackground source={ require('../../../assets/images/Group 12.png')}>
          </ImageBackground>
        </View>
        <View style={style.container}>
          <Text style={style.textLoginStyle2}>Login</Text>
          
          <ImageBackground source={ require('../../../assets/images/Rectangles.png')}>
          <ImageBackground source={ require('../../../assets/images/Smile.png')} style={{marginBottom:10}}/>
                <View style={{ backgroundColor: '#CBCBCB', height: 50, flexDirection: 'row', width: '90%', alignSelf: 'center', borderRadius: 10, marginTop:90 }}>
                  <Icon name="email" size={20} color="#F8F8FF" style={{ flex: 1, padding: 15 }} />
                    <TextInput
                        style={{ width: '90%', padding: 15 }}
                        placeholder="Enter your email"
                        value={email}
                        onChangeText={setEmail}
                        keyboardType="email-address"
                    />
                </View>
                <View style={{ backgroundColor: '#CBCBCB', height: 50, flexDirection: 'row', width: '90%', alignSelf: 'center', marginTop: 30, borderRadius: 10 }}>
                  <Icon name="lock" size={20} color="#F8F8FF" style={{ flex: 1, padding: 15 }} />
                    <TextInput
                        style={{ width: '90%', padding: 15 }}
                        placeholder="Password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                    />
                </View>

                <View style={{ width: '90%', flexDirection: 'row', marginHorizontal: 'auto', height: '50', padding: 10, marginTop: 10, marginBottom: '10%' }}>
                    <CheckBox
                        value={checked}
                        onValueChange={setChecked}
                        style={{}}
                    />
                    <Text style={{ marginLeft: 10, flex: 8 }}>Remember me </Text>
                    <TouchableOpacity onPress={() => { }} style={{}}>
                        <Text style={{ color: '#4D7881' }}>Forget password?</Text>
                    </TouchableOpacity>
                </View>
                <View>
                    <TouchableOpacity onPress={handleLogin} style={{ width: '90%', alignSelf: 'center', height: 50, backgroundColor: '#4D7881', borderRadius: 10, }}>
                        <Text style={{ marginVertical: 'auto', textAlign: 'center', fontSize: 20, color: 'white' }}>Next</Text>
                    </TouchableOpacity>
                    <View style={{flexDirection: 'row', alignSelf: 'center', marginTop: 10}}>
                        <Text>New Member?</Text>
                        <Text onPress={handleLogin} style={{marginLeft: 5, color: '#4D7881'}}>Register now</Text>
                    </View>
                </View>
      </ImageBackground>
      </View>
    </ScrollView>
  );
}


const style = StyleSheet.create({
  container: {
    padding: 10
  },
  textInputStyle: {
    height: "45",
    marginTop: 12,
    borderWidth: 1,
    padding: 10,
    borderRadius:10,
  },
  textForgot: {
    marginTop: 5,
    textAlign: 'right',
    padding:15,
    color:'#1F41BB',
    fontWeight:'bold'
  },
  textLoginStyle: {
    fontSize: 32,
    marginTop: 50,
    fontWeight: 'bold',
    textAlign: 'center',
    color:'#1F41BB',
  
  },
  textSignin: {
    textAlign: "center",
    marginVertical: "auto",
    color: "white",
    flex: 1,
    fontSize: 18
  },
  buttonLogin: {
    backgroundColor: '#1F41BB',
    height: 60,
    width: '100%',
    alignSelf: "center",
    borderRadius: 10,
    flexDirection: "row",
  },
  textLoginStyle2: {
    fontSize: 25,
    marginTop: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    alignSelf: 'center',
    marginBottom:250
  },
  brandStyle: {
    marginTop: 100,
    alignItems: 'center',
    justifyContent: 'center'
  },
  textLabel: {
    fontSize: 12,
    fontWeight: 'bold'
  },
  btnContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  btnContainer1:{
    marginRight:15
  },
  textContinueStyle: {
    textAlign: 'center',
    marginBottom: 50
  },
  textContinueStyle2: {
    textAlign: 'center',
    color: '#1F41BB',
    fontWeight: 'bold',
    marginBottom:5
  },
})
export default LoginScreen;