import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {
  WelcomeScreen,
  RegisterScreen,
  LoginScreen
} from "./rizqialfatih"
const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer independent={true}>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" 
          options={{headerShown:false}}
          component={LoginScreen} />
        <Stack.Screen name="Welcome" 
          options={{headerShown:false}}
          component={WelcomeScreen} />
        <Stack.Screen name="Register" 
          options={{headerShown:false}}
          component={RegisterScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;